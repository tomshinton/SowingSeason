#include <Runtime/Core/Public/Modules/ModuleManager.h>
 
class FEmptyModule : public IModuleInterface
{
	virtual void StartupModule() override { }
	virtual void ShutdownModule() override { }
};

IMPLEMENT_MODULE(FEmptyModule, Empty)